#!/bin/bash

# Define JSON URL
URL="https://services.swpc.noaa.gov/json/ovation_aurora_latest.json"
OUT="/opt/hamclock-backend/htdocs/ham/HamClock/aurora/aurora.txt"

# 1. Fetch the JSON data
# 2. Use jq to dig into the 'coordinates' array
# 3. Extract the 3rd element (index 2) from every sub-array
# 4. Use the max filter to find the highest value
MAX_VALUE=$(curl -s "$URL" | jq '.coordinates | map(.[2]) | max')

# Get the current UNIX epoch time
EPOCH_TIME=$(date +%s)

# Format the output and append to aurora.txt
echo "$EPOCH_TIME $MAX_VALUE" >> "$OUT"
